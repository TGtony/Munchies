from sklearn.externals import joblib

classification_model = joblib.load('svm_model.pk1') # load SVM model

with open("asin_list.txt", 'r') as input: # load list of ASIN
    asin = [line.rstrip('\n') for line in input]

# command line?
#import sys
#pred = []
#vec = argv[1]
#for i in vec:
#    pred.append(i)

pred = [[ 0 for x in range (300) ]] # initialize prediction vector to all 0s

# test:
pred[0][234] = 1 #salty
pred[0][48] = 1 #cheese
pred[0][60] = 1 #crispy

result = classification_model.predict_proba(pred)[0] # calculates probability

proba_dict = dict(zip(classification_model.classes_, result)) # create dictionary ( label: probability )

sorted_results = list(map(lambda x: x[0], sorted(zip(classification_model.classes_, result), key=lambda x: x[1]))) # sort

for index in sorted_results[:10]: # print in order of highest probability to lowest, currently set to print top 100
    print(asin[index])

result2 = classification_model.predict(pred) # print #1 match (this is usually the same as the highest probability in predict_proba)
print ('\n')
index2 = result2[0]
print (asin[index2])
