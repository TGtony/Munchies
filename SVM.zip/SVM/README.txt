predict.py
	* RUN THIS ONE FOR PREDICTION
	- make sure to have all the "svm_model.pk1" files in the same directory as predict.py
		(that is where the svm model is)
	- make sure to have "asin_list.txt" in the same directory as predict.py
		(needed to match the label returned by prediction to an ASIN)
	- since I'm not sure how the app and site is passing the prediction vector,
		testing was done with the an initialized vector within
	- refer to features_list.txt for seting values in prediction vector for testing

tfidfandsvm.py
	* not necessary to run since the model is already saved in "svm_model.pk1" files,
		unless changes need to be made to the model
	- used to generate the svm model (stored in the "svm_model.pk1" files)
	- requires "chip_product_adjectives.txt" and "top100.txt" in the same directory
	- generates the "asin_list.txt" and "features_list.txt"